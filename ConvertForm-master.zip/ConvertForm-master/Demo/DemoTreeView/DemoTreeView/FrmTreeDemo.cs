﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DemoTreeView
{
    public partial class FrmTreeView : Form
    {
        public FrmTreeView()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {

        }

        private void treeDirectories_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {

        }

        private void treeDirectories_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {

        }

    }
}
