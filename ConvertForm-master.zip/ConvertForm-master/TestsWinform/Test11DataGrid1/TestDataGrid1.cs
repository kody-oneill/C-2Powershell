using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test11DataGrid1
{
    public partial class TestDataGrid1 : Form
    {
        public TestDataGrid1()
        {
            InitializeComponent();
        }
    }
}