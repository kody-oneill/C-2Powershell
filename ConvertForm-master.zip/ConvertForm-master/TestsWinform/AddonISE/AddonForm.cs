﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AddonISE
{
    public partial class AddonFrm : Form
    {
        public AddonFrm()
        {
            InitializeComponent();
        }

        private void AddonFrm_Load(object sender, EventArgs e)
        {

        }

        private void AddonFrm_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void AddonFrm_Shown(object sender, EventArgs e)
        {

        }

        private void btnExecute_Click(object sender, EventArgs e)
        {

        }

        private void btnInsert_Click(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {

        }
    }
}
