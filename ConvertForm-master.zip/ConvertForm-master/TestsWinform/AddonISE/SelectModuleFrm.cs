﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AddonISE
{
    public partial class SelectModuleFrm : Form
    {
        public SelectModuleFrm()
        {
            InitializeComponent();
        }

        private void lstbxModulesName_DoubleClick(object sender, EventArgs e)
        {

        }
    }
}
