using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test4Font
{
    public partial class FrmTest4Font : Form
    {
        public FrmTest4Font()
        {
            InitializeComponent();
        }
    }
}