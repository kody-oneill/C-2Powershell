using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test15ProgressBarTimer
{
    public partial class FrmTest15ProgressBarTimer : Form
    {
        public FrmTest15ProgressBarTimer()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }
    }
}