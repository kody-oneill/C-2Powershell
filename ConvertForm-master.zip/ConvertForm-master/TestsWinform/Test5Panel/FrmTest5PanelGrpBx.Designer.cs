﻿namespace Test5Panel
{
    partial class FrmTest5PanelGrpBx
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.PanelMainFill = new System.Windows.Forms.Panel();
            this.panelCenterFill = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.grpBxFillInpanelBottom = new System.Windows.Forms.GroupBox();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panelTop = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.PanelMainFill.SuspendLayout();
            this.panelCenterFill.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.grpBxFillInpanelBottom.SuspendLayout();
            this.panelTop.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelMainFill
            // 
            this.PanelMainFill.Controls.Add(this.panelCenterFill);
            this.PanelMainFill.Controls.Add(this.panelBottom);
            this.PanelMainFill.Controls.Add(this.panelTop);
            this.PanelMainFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelMainFill.Location = new System.Drawing.Point(0, 0);
            this.PanelMainFill.Name = "PanelMainFill";
            this.PanelMainFill.Size = new System.Drawing.Size(485, 296);
            this.PanelMainFill.TabIndex = 0;
            // 
            // panelCenterFill
            // 
            this.panelCenterFill.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelCenterFill.Controls.Add(this.tabControl1);
            this.panelCenterFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCenterFill.Location = new System.Drawing.Point(0, 79);
            this.panelCenterFill.Name = "panelCenterFill";
            this.panelCenterFill.Size = new System.Drawing.Size(485, 109);
            this.panelCenterFill.TabIndex = 2;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(485, 109);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(477, 83);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(477, 83);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panelBottom
            // 
            this.panelBottom.BackColor = System.Drawing.SystemColors.Info;
            this.panelBottom.Controls.Add(this.grpBxFillInpanelBottom);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBottom.Location = new System.Drawing.Point(0, 188);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(485, 108);
            this.panelBottom.TabIndex = 1;
            // 
            // grpBxFillInpanelBottom
            // 
            this.grpBxFillInpanelBottom.Controls.Add(this.checkedListBox1);
            this.grpBxFillInpanelBottom.Controls.Add(this.button1);
            this.grpBxFillInpanelBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grpBxFillInpanelBottom.Location = new System.Drawing.Point(0, 0);
            this.grpBxFillInpanelBottom.Name = "grpBxFillInpanelBottom";
            this.grpBxFillInpanelBottom.Size = new System.Drawing.Size(485, 108);
            this.grpBxFillInpanelBottom.TabIndex = 0;
            this.grpBxFillInpanelBottom.TabStop = false;
            this.grpBxFillInpanelBottom.Text = "groupBox1";
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(3, 16);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(206, 79);
            this.checkedListBox1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(379, 84);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelTop.Controls.Add(this.splitContainer1);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(485, 79);
            this.panelTop.TabIndex = 0;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Size = new System.Drawing.Size(485, 79);
            this.splitContainer1.SplitterDistance = 209;
            this.splitContainer1.TabIndex = 0;
            // 
            // FormPanelGrpBx
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 296);
            this.Controls.Add(this.PanelMainFill);
            this.Name = "FormPanelGrpBx";
            this.Text = "Form1";
            this.PanelMainFill.ResumeLayout(false);
            this.panelCenterFill.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.panelBottom.ResumeLayout(false);
            this.grpBxFillInpanelBottom.ResumeLayout(false);
            this.panelTop.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelMainFill;
        private System.Windows.Forms.Panel panelCenterFill;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.GroupBox grpBxFillInpanelBottom;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
    }
}

