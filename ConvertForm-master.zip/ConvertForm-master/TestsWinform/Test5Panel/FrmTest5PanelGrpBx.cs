using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test5Panel
{
    public partial class FrmTest5PanelGrpBx : Form
    {
        public FrmTest5PanelGrpBx()
        {
            InitializeComponent();
        }
    }
}