using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test7WebBrowser
{
    public partial class FrmTest7WebBrowser : Form
    {
        public FrmTest7WebBrowser()
        {
            InitializeComponent();
        }
    }
}