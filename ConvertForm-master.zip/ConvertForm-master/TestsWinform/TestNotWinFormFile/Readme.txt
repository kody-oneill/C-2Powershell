Les fichiers contenus dans ce r�pertoire permettent de valider la recherche de fichiers Forms.Designer.cs
