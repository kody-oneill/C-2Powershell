﻿
namespace Test20ClassLibrary
{
    public class Class1
    {
        static private int test = 10;
    }
}
