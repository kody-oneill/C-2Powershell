using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AutoCompletion
{
    public partial class FrmTest17AutoCompletion : Form
    {
        public FrmTest17AutoCompletion()
        {
            InitializeComponent();
        }
    }
}