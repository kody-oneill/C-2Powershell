using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test14BoitesDeDialogue
{
    public partial class FrmTest14BoitesDeDialogue : Form
    {
        public FrmTest14BoitesDeDialogue()
        {
            InitializeComponent();
        }
    }
}