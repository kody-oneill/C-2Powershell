using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test6Composants
{
    public partial class FrmTest6Composants : Form
    {
        public FrmTest6Composants()
        {
            InitializeComponent();
        }
    }
}