using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test8PictureBox
{
    public partial class FrmTest8PictureBox : Form
    {
        public FrmTest8PictureBox()
        {
            InitializeComponent();
        }
    }
}