﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test10Propriété1
{
    public partial class FrmTest10Propriété1 : Form
    {
        public FrmTest10Propriété1()
        {
            InitializeComponent();
        }
    }
}