using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EventHandlerWinFormOnly
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Activated(object sender, EventArgs e)
        {

        }

        private void Form1_AutoSizeChanged(object sender, EventArgs e)
        {

        }

        private void Form1_AutoValidateChanged(object sender, EventArgs e)
        {

        }

        private void Form1_BackColorChanged(object sender, EventArgs e)
        {

        }

        private void Form1_BackgroundImageChanged(object sender, EventArgs e)
        {

        }

        private void Form1_BackgroundImageLayoutChanged(object sender, EventArgs e)
        {

        }

        private void Form1_BindingContextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_CausesValidationChanged(object sender, EventArgs e)
        {

        }

        private void Form1_ChangeUICues(object sender, UICuesEventArgs e)
        {

        }

        private void Form1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_ClientSizeChanged(object sender, EventArgs e)
        {

        }

        private void Form1_ContextMenuStripChanged(object sender, EventArgs e)
        {

        }

        private void Form1_ControlAdded(object sender, ControlEventArgs e)
        {

        }

        private void Form1_ControlRemoved(object sender, ControlEventArgs e)
        {

        }

        private void Form1_CursorChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Deactivate(object sender, EventArgs e)
        {

        }

        private void Form1_DockChanged(object sender, EventArgs e)
        {

        }

        private void Form1_DoubleClick(object sender, EventArgs e)
        {

        }

        private void Form1_DragDrop(object sender, DragEventArgs e)
        {

        }

        private void Form1_DragEnter(object sender, DragEventArgs e)
        {

        }

        private void Form1_DragLeave(object sender, EventArgs e)
        {

        }

        private void Form1_DragOver(object sender, DragEventArgs e)
        {

        }

        private void Form1_EnabledChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_FontChanged(object sender, EventArgs e)
        {

        }

        private void Form1_ForeColorChanged(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void Form1_GiveFeedback(object sender, GiveFeedbackEventArgs e)
        {

        }

        private void Form1_HelpButtonClicked(object sender, CancelEventArgs e)
        {

        }

        private void Form1_HelpRequested(object sender, HelpEventArgs hlpevent)
        {

        }

        private void Form1_ImeModeChanged(object sender, EventArgs e)
        {

        }

        private void Form1_InputLanguageChanged(object sender, InputLanguageChangedEventArgs e)
        {

        }

        private void Form1_InputLanguageChanging(object sender, InputLanguageChangingEventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {

        }

        private void Form1_Layout(object sender, LayoutEventArgs e)
        {

        }

        private void Form1_Leave(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_LocationChanged(object sender, EventArgs e)
        {

        }

        private void Form1_MaximizedBoundsChanged(object sender, EventArgs e)
        {

        }

        private void Form1_MaximumSizeChanged(object sender, EventArgs e)
        {

        }

        private void Form1_MdiChildActivate(object sender, EventArgs e)
        {

        }

        private void Form1_MinimumSizeChanged(object sender, EventArgs e)
        {

        }

        private void Form1_MouseCaptureChanged(object sender, EventArgs e)
        {

        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void Form1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void Form1_MouseEnter(object sender, EventArgs e)
        {

        }

        private void Form1_MouseHover(object sender, EventArgs e)
        {

        }

        private void Form1_MouseLeave(object sender, EventArgs e)
        {

        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {

        }

        private void Form1_Move(object sender, EventArgs e)
        {

        }

        private void Form1_PaddingChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_ParentChanged(object sender, EventArgs e)
        {

        }

        private void Form1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {

        }

        private void Form1_QueryAccessibilityHelp(object sender, QueryAccessibilityHelpEventArgs e)
        {

        }

        private void Form1_QueryContinueDrag(object sender, QueryContinueDragEventArgs e)
        {

        }

        private void Form1_RegionChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Resize(object sender, EventArgs e)
        {

        }

        private void Form1_ResizeBegin(object sender, EventArgs e)
        {

        }

        private void Form1_ResizeEnd(object sender, EventArgs e)
        {

        }

        private void Form1_RightToLeftChanged(object sender, EventArgs e)
        {

        }

        private void Form1_RightToLeftLayoutChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Scroll(object sender, ScrollEventArgs e)
        {

        }

        private void Form1_Shown(object sender, EventArgs e)
        {

        }

        private void Form1_SizeChanged(object sender, EventArgs e)
        {

        }

        private void Form1_StyleChanged(object sender, EventArgs e)
        {

        }

        private void Form1_SystemColorsChanged(object sender, EventArgs e)
        {

        }

        private void Form1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Validated(object sender, EventArgs e)
        {

        }

        private void Form1_Validating(object sender, CancelEventArgs e)
        {

        }

        private void Form1_VisibleChanged(object sender, EventArgs e)
        {

        }
    }
}