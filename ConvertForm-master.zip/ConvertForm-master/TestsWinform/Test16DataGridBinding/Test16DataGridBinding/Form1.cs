using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test16DataGridBinding
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnQuitter_Click(object sender, EventArgs e)
        {

        }

        private void dtGrdVw_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dtGrdVw_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {

        }

        private void dtGrdVw_DataSourceChanged(object sender, EventArgs e)
        {

        }

        private void dtGrdVw_BindingContextChanged(object sender, EventArgs e)
        {

        }

        private void dtGrdVw_DataMemberChanged(object sender, EventArgs e)
        {

        }
    }
}